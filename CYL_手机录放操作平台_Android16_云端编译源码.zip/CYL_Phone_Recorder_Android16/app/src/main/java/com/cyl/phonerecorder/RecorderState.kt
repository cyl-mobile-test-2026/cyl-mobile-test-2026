package com.cyl.phonerecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object RecorderState {
    @Volatile var recording = false
    @Volatile var playing = false
    val actions = mutableListOf<ActionItem>()
    private const val PREF = "cyl_recorder"
    private const val KEY = "actions"

    @Synchronized fun persist(context: Context) {
        val arr = JSONArray()
        actions.forEach {
            arr.put(JSONObject().apply {
                put("type", it.type); put("x", it.x); put("y", it.y)
                put("x2", it.x2); put("y2", it.y2); put("delay", it.delayMs)
                put("duration", it.durationMs); put("w", it.screenW); put("h", it.screenH)
            })
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized fun load(context: Context) {
        actions.clear()
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            actions.add(ActionItem(o.getString("type"), o.getDouble("x").toFloat(),
                o.getDouble("y").toFloat(), o.getDouble("x2").toFloat(), o.getDouble("y2").toFloat(),
                o.getLong("delay"), o.getLong("duration"), o.getInt("w"), o.getInt("h")))
        }
    }
}
