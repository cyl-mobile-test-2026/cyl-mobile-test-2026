package com.cyl.phonerecorder

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import org.json.JSONArray
import org.json.JSONObject

class RecorderAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastEventAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !RecorderState.recording) return
        val now = System.currentTimeMillis()
        val delay = if (lastEventAt == 0L) 0L else (now - lastEventAt).coerceAtMost(10_000L)
        lastEventAt = now

        val rect = Rect()
        event.source?.let { node ->
            node.getBoundsInScreen(rect)
            node.recycle()
        }
        if (rect.isEmpty) return

        val dm = resources.displayMetrics
        val x = rect.centerX().toFloat()
        val y = rect.centerY().toFloat()

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_SELECTED -> {
                RecorderState.actions.add(
                    ActionItem("tap", x, y, x, y, delay, 80L, dm.widthPixels, dm.heightPixels)
                )
                RecorderState.persist(this)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // Scroll events expose the affected view bounds, not the user's exact finger path.
                // Store a conservative vertical swipe through the center of that view.
                val top = (rect.top + rect.height() * 0.72f)
                val bottom = (rect.top + rect.height() * 0.28f)
                RecorderState.actions.add(
                    ActionItem("swipe", rect.centerX().toFloat(), top, rect.centerX().toFloat(),
                        bottom, delay, 420L, dm.widthPixels, dm.heightPixels)
                )
                RecorderState.persist(this)
            }
        }
    }

    override fun onInterrupt() {}

    fun playNext(items: List<ActionItem>, index: Int, speed: Float, repeatLeft: Int) {
        if (!RecorderState.playing) return
        if (index >= items.size) {
            if (repeatLeft > 1) playNext(items, 0, speed, repeatLeft - 1)
            else RecorderState.playing = false
            return
        }
        val item = items[index]
        val dm = resources.displayMetrics
        val sx = dm.widthPixels.toFloat() / item.screenW.coerceAtLeast(1)
        val sy = dm.heightPixels.toFloat() / item.screenH.coerceAtLeast(1)
        val path = Path().apply {
            moveTo(item.x * sx, item.y * sy)
            if (item.type == "swipe") lineTo(item.x2 * sx, item.y2 * sy)
        }
        val duration = (item.durationMs / speed.coerceIn(0.5f, 5f)).toLong().coerceAtLeast(50L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        val wait = (item.delayMs / speed.coerceIn(0.5f, 5f)).toLong()
        handler.postDelayed({
            if (!RecorderState.playing) return@postDelayed
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    handler.postDelayed({ playNext(items, index + 1, speed, repeatLeft) }, 80L)
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    RecorderState.playing = false
                }
            }, handler)
        }, wait)
    }

    companion object {
        @Volatile var instance: RecorderAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
}
