package com.cyl.phonerecorder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var count: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RecorderState.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "CYL 手机录放操作平台"
            textSize = 24f
            setPadding(0, 8, 0, 18)
        }
        val subtitle = TextView(this).apply {
            text = "Android 16 · 小米 14 Pro 适配测试版"
            textSize = 14f
            setPadding(0, 0, 0, 24)
        }
        count = TextView(this).apply { textSize = 17f; setPadding(0, 12, 0, 20) }
        fun button(label: String, action: () -> Unit) =
            Button(this).apply { text = label; textSize = 16f; setOnClickListener { action() } }

        root.addView(title); root.addView(subtitle)
        root.addView(button("① 开启无障碍服务") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("② 开始录制") {
            if (RecorderAccessibilityService.instance == null) {
                Toast.makeText(this, "请先开启 CYL 操作录放服务", Toast.LENGTH_LONG).show()
            } else {
                RecorderState.actions.clear()
                RecorderState.recording = true
                RecorderState.playing = false
                updateCount()
                Toast.makeText(this, "开始记录可访问界面的操作", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(button("停止录制 / 保存") {
            RecorderState.recording = false
            RecorderState.persist(this)
            updateCount()
            Toast.makeText(this, "已保存 ${RecorderState.actions.size} 条操作", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("播放（1倍速，单次）") {
            RecorderState.load(this)
            val service = RecorderAccessibilityService.instance
            if (service == null) Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_LONG).show()
            else if (RecorderState.actions.isEmpty()) Toast.makeText(this, "没有可播放的记录", Toast.LENGTH_SHORT).show()
            else {
                RecorderState.playing = true
                service.playNext(RecorderState.actions.toList(), 0, 1f, 1)
            }
        })
        root.addView(button("停止回放") { RecorderState.playing = false })
        root.addView(button("清空记录") {
            RecorderState.recording = false
            RecorderState.playing = false
            RecorderState.actions.clear()
            RecorderState.persist(this)
            updateCount()
        })
        root.addView(count)
        val note = TextView(this).apply {
            text = "说明：当前原型通过 Android 无障碍事件记录可访问控件的点击/滚动，再用系统手势接口回放。它还不是完整的全局原始触摸录制器；部分游戏、画布、受保护页面及系统界面可能无法准确记录。"
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }
        root.addView(note)
        setContentView(root)
        updateCount()
    }

    private fun updateCount() {
        if (::count.isInitialized) count.text = "当前记录：${RecorderState.actions.size} 条"
    }
}
