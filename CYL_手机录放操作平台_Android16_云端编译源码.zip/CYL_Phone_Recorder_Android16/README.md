# CYL 手机录放操作平台（Android 16 原型工程）

目标设备：小米 14 Pro / Android 16（HyperOS）。

## 打开方式
1. 在电脑安装 Android Studio（建议使用支持 Android SDK 36 的较新版本）。
2. Android Studio -> Open，选择本工程目录。
3. 等待 Gradle 同步，安装 Android SDK Platform 36 和 Build Tools。
4. 连接手机，允许 USB 调试，点击 Run；或 Build -> Build APK(s)。

## 手机上首次使用
1. 打开应用，点击“开启无障碍服务”。
2. 在系统无障碍设置中找到“CYL操作录放服务”并开启。
3. 返回应用，点击“开始录制”，再进入目标应用操作。
4. 返回本应用点击“停止录制 / 保存”，再点击播放。

## 当前原型边界（务必阅读）
- 当前版本记录的是无障碍框架可观察到的控件点击/滚动事件，并非系统级原始触摸事件。
- 滚动动作按控件区域估算为垂直滑动；点击按控件边界中心回放，因此不保证像素级还原。
- 游戏、绘图/视频画布、部分自定义控件、受保护页面、系统权限窗口可能无法正确记录。
- 当前没有悬浮球、任务多文件管理、循环/倍速设置界面、导入导出功能；这些列入后续迭代。
- 小米 HyperOS 可能对后台服务实施额外限制。若回放中途停止，需要在系统设置中允许应用自启动并取消电池限制（菜单名称可能因系统版本不同）。
- 无障碍权限非常敏感。只在本人知情并授权的设备上使用；不要用于绕过登录、支付、验证码或应用安全机制。

## 技术
- Kotlin / 原生 Android
- compileSdk 36, targetSdk 35, minSdk 26
- AccessibilityService + dispatchGesture

## 云端自动编译 APK（无需本地 Android Studio）
本工程已附 GitHub Actions 工作流 `.github/workflows/build-apk.yml`：
1. 将整个工程 ZIP 解压后，上传到你自己的 GitHub 新建仓库（仓库建议设为 Private）。
2. 上传完成后打开仓库的 Actions 页面，选择 `Build Android APK`，点击 `Run workflow`。
3. 编译完成后打开该次运行记录，在 Artifacts 下载 `CYL-Phone-Recorder-debug-apk`，解压即可得到 `app-debug.apk`。
4. 将 APK 传到小米 14 Pro 安装测试。首次安装可能需要允许该来源安装应用。

该方式仍需要一次性创建/上传 GitHub 仓库；GitHub 云端负责 Android SDK/Gradle 编译。Debug APK 仅用于测试，不是上架签名包。
