package com.cyl.phonerecorder
data class ActionItem(val type:String,val x:Float,val y:Float,val x2:Float,val y2:Float,val delayMs:Long,val durationMs:Long,val w:Int,val h:Int)
