package com.cyl.phonerecorder
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
object RecorderState {
 @Volatile var recording=false
 @Volatile var playing=false
 @Volatile var status="无障碍服务未连接"
 val actions= mutableListOf<ActionItem>()
 private const val PREF="cyl_v02"; private const val KEY="actions"
 @Synchronized fun save(c:Context) {
  val a=JSONArray()
  actions.forEach { v -> a.put(JSONObject().apply { put("t",v.type);put("x",v.x);put("y",v.y);put("x2",v.x2);put("y2",v.y2);put("d",v.delayMs);put("du",v.durationMs);put("w",v.w);put("h",v.h) }) }
  c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply()
 }
 @Synchronized fun load(c:Context) {
  actions.clear(); val a=JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]") ?: "[]")
  for(i in 0 until a.length()) { val o=a.getJSONObject(i); actions.add(ActionItem(o.getString("t"),o.getDouble("x").toFloat(),o.getDouble("y").toFloat(),o.getDouble("x2").toFloat(),o.getDouble("y2").toFloat(),o.getLong("d"),o.getLong("du"),o.getInt("w"),o.getInt("h"))) }
 }
}
