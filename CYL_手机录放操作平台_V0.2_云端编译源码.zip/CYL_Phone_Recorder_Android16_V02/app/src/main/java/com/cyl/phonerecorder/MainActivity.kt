package com.cyl.phonerecorder
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
class MainActivity:Activity(){
 private lateinit var status:TextView;private lateinit var count:TextView
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);RecorderState.load(this)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL;setPadding(24,30,24,24)}
  root.addView(TextView(this).apply{text="CYL 手机录放操作平台";textSize=24f})
  root.addView(TextView(this).apply{text="V0.2.0 · Android 16 测试版";textSize=13f})
  status=TextView(this).apply{textSize=16f};count=TextView(this).apply{textSize=16f};root.addView(status);root.addView(count)
  fun btn(t:String,f:()->Unit){root.addView(Button(this).apply{text=t;setOnClickListener{f();refresh()}})}
  btn("开启无障碍服务"){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
  btn("开始录制"){RecorderAccessibilityService.instance?.startRec()?:Toast.makeText(this,"请先开启无障碍服务",Toast.LENGTH_LONG).show()}
  btn("停止录制并保存"){RecorderAccessibilityService.instance?.stopRec()}
  btn("5秒倒计时后回放"){RecorderAccessibilityService.instance?.play()?:Toast.makeText(this,"无障碍服务未连接",Toast.LENGTH_LONG).show()}
  btn("停止回放"){RecorderAccessibilityService.instance?.stopPlay()}
  btn("刷新状态"){ }
  root.addView(TextView(this).apply{text="说明：本版本通过无障碍事件记录可访问控件的点击及部分滚动；游戏、画布、自定义控件及受保护界面可能无法记录。播放前请在倒计时内切换到目标应用。";textSize=12f})
  setContentView(root);refresh()
 }
 override fun onResume(){super.onResume();if(::status.isInitialized)refresh()}
 private fun refresh(){RecorderState.load(this);status.text="服务状态："+RecorderState.status;count.text="记录数量："+RecorderState.actions.size+"条"}
}
