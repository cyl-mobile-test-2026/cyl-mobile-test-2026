package com.cyl.phonerecorder
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class RecorderAccessibilityService: AccessibilityService() {
 private val h=Handler(Looper.getMainLooper()); private var last=0L
 private var wm:WindowManager?=null; private var panel:LinearLayout?=null
 private var list:List<ActionItem> = emptyList(); private var index=0
 override fun onServiceConnected(){ super.onServiceConnected(); instance=this; RecorderState.status="无障碍服务已连接"; makePanel() }
 override fun onAccessibilityEvent(e:AccessibilityEvent?) {
  if(e==null || !RecorderState.recording) return
  if(e.eventType!=AccessibilityEvent.TYPE_VIEW_CLICKED && e.eventType!=AccessibilityEvent.TYPE_VIEW_SELECTED && e.eventType!=AccessibilityEvent.TYPE_VIEW_SCROLLED) return
  val r=Rect(); val n=e.source ?: return; n.getBoundsInScreen(r); n.recycle(); if(r.isEmpty)return
  val now=System.currentTimeMillis(); val delay=if(last==0L)0L else (now-last).coerceIn(0L,10000L); last=now
  val dm=resources.displayMetrics
  val a=if(e.eventType==AccessibilityEvent.TYPE_VIEW_SCROLLED) {
   val x=r.centerX().toFloat(); ActionItem("swipe",x,r.top+r.height()*0.72f,x,r.top+r.height()*0.28f,delay,450,dm.widthPixels,dm.heightPixels)
  } else ActionItem("tap",r.centerX().toFloat(),r.centerY().toFloat(),r.centerX().toFloat(),r.centerY().toFloat(),delay,100,dm.widthPixels,dm.heightPixels)
  synchronized(RecorderState.actions){RecorderState.actions.add(a)}; RecorderState.save(this); RecorderState.status="录制中：${RecorderState.actions.size}条"
 }
 fun startRec(){ RecorderState.actions.clear();last=0;RecorderState.playing=false;RecorderState.recording=true;RecorderState.status="正在录制";say("开始录制") }
 fun stopRec(){RecorderState.recording=false;RecorderState.save(this);RecorderState.status="已保存${RecorderState.actions.size}条";say("已保存${RecorderState.actions.size}条")}
 fun play(){ if(RecorderState.recording)stopRec();RecorderState.load(this);if(RecorderState.actions.isEmpty()){say("没有可回放记录");return};list=RecorderState.actions.toList();index=0;RecorderState.playing=true;RecorderState.status="5秒后回放";say("请切换到目标应用，5秒后开始");h.postDelayed({next()},5000) }
 private fun next(){
  if(!RecorderState.playing)return
  if(index>=list.size){RecorderState.playing=false;RecorderState.status="回放完成";say("回放完成");return}
  val a=list[index];val dm=resources.displayMetrics;val sx=dm.widthPixels.toFloat()/a.w.coerceAtLeast(1);val sy=dm.heightPixels.toFloat()/a.h.coerceAtLeast(1)
  val x=(a.x*sx).coerceIn(1f,dm.widthPixels-2f);val y=(a.y*sy).coerceIn(1f,dm.heightPixels-2f)
  val p=Path().apply{moveTo(x,y);if(a.type=="swipe")lineTo((a.x2*sx).coerceIn(1f,dm.widthPixels-2f),(a.y2*sy).coerceIn(1f,dm.heightPixels-2f))}
  val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,a.durationMs.coerceAtLeast(60))).build()
  h.postDelayed({ if(RecorderState.playing){val ok=dispatchGesture(g,object:GestureResultCallback(){
   override fun onCompleted(d:GestureDescription?){index++;RecorderState.status="回放中：$index/${list.size}";h.postDelayed({next()},150)}
   override fun onCancelled(d:GestureDescription?){RecorderState.playing=false;RecorderState.status="系统取消手势";say("系统取消手势")}
  },h);if(!ok){RecorderState.playing=false;RecorderState.status="系统未接受手势";say("系统未接受手势")}} },a.delayMs.coerceIn(0L,10000L))
 }
 fun stopPlay(){RecorderState.playing=false;h.removeCallbacksAndMessages(null);RecorderState.status="已停止回放";say("已停止回放")}
 private fun say(s:String){h.post{Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}}
 private fun makePanel(){
  if(panel!=null)return
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(6,6,6,6);setBackgroundColor(0xEE263238.toInt())}
  box.addView(TextView(this).apply{text="CYL 录放";setTextColor(-1);textSize=12f})
  fun b(t:String,f:()->Unit){box.addView(Button(this).apply{text=t;textSize=10f;setOnClickListener{f()}})}
  b("开始录制"){startRec()};b("停止保存"){stopRec()};b("延时播放"){play()};b("停止回放"){stopPlay()}
  val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=8;y=160}
  try{wm?.addView(box,lp);panel=box}catch(_:Exception){RecorderState.status="悬浮面板创建失败"}
 }
 override fun onInterrupt(){stopPlay()}
 override fun onDestroy(){stopPlay();try{panel?.let{wm?.removeView(it)}}catch(_:Exception){};panel=null;instance=null;RecorderState.status="服务已断开";super.onDestroy()}
 companion object{@Volatile var instance:RecorderAccessibilityService?=null}
}
